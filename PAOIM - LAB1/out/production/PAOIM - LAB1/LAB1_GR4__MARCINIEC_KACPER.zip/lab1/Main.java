package lab1;

public class Main {
  public static void main(String[] args) {
    new ConsoleUserInterface().run();
  }
}
